﻿

 theUILang.streamData		= "Stream (xspf)";
 theUILang.cantAccessData	= "Webserver user can't access the data of this torrent.";

thePlugins.get("stream").langLoaded();
