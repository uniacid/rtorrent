﻿

 theUILang.streamData		= "Verkrijg data";
 theUILang.cantAccessData	= "Web-server user heeft geen toegang tot de data van deze torrent.";

thePlugins.get("stream").langLoaded();